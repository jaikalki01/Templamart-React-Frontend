export const BASE_URL =  "https://templamart.com/api/api/v1";
export const DOMAIN =  "https://templamart.com";